#!/usr/bin/env bash
# Produces curl_transcript.txt (all calls use -i). Run: npm run demo
cd "$(dirname "$0")"
OUT=curl_transcript.txt
B=http://localhost:8080
: > "$OUT"

node eligiblity/mock-scholarship.js >/dev/null 2>&1 & MOCK=$!
node eligiblity/app.js >/dev/null 2>&1 & APP=$!
trap 'kill $MOCK $APP 2>/dev/null' EXIT
sleep 2

run() {  # run "title" curl-args...
    local title="$1"; shift
    { echo; echo "######## $title"; echo "\$ curl -i $*"; curl -i -s "$@"; echo; } | tee -a "$OUT"
}

run "1. Successful create (201 + Location)" -X POST $B/evaluations \
    -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-key-001' \
    -d '{"studentId":101,"scholarshipId":1,"cgpa":8.8,"annualIncome":400000}'

run "2. Same request, same Idempotency-Key -> original returned (200)" -X POST $B/evaluations \
    -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-key-001' \
    -d '{"studentId":101,"scholarshipId":1,"cgpa":8.8,"annualIncome":400000}'

run "3a. Malformed body - invalid value (400)" -X POST $B/evaluations \
    -H 'Content-Type: application/json' \
    -d '{"studentId":101,"scholarshipId":1,"cgpa":15.0,"annualIncome":400000}'

run "3b. Malformed body - broken JSON (400)" -X POST $B/evaluations \
    -H 'Content-Type: application/json' -d '{"studentId":101,'

run "4. Missing resource (404)" $B/evaluations/9999 -H 'Accept: application/json'

run "5a. Override, first time (202)" -X POST $B/evaluations/1/override \
    -H 'Content-Type: application/json' -d '{"reason":"Appeal approved"}'

run "5b. Override again -> state conflict (409)" -X POST $B/evaluations/1/override \
    -H 'Content-Type: application/json' -d '{"reason":"Appeal approved"}'

echo; echo "Saved to $OUT"
