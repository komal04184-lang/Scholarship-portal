# assgn4 - Eligibility Service

```bash
npm install
npm test            # 4 Jest tests
npm run validate    # OpenAPI validator, expect: openapi.yaml is valid
npm run demo        # starts both servers, writes curl_transcript.txt (curl -i)
```

Manual run: `npm run mock-scholarship` (port 8081) and `npm start` (port 8080).
