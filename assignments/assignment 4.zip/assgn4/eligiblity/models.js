// eligibility/models.js
class EvaluationRecord {
    constructor({ id, studentId, scholarshipId, cgpa, annualIncome, status, reason, idempotencyKey, createdAt, adminOverrideReason = null }) {
        this.id = id;
        this.studentId = studentId;
        this.scholarshipId = scholarshipId;
        this.cgpa = cgpa;
        this.annualIncome = annualIncome;
        this.status = status; // 'ELIGIBLE' | 'INELIGIBLE' | 'OVERRIDDEN'
        this.reason = reason;
        this.idempotencyKey = idempotencyKey;
        this.createdAt = createdAt;
        this.adminOverrideReason = adminOverrideReason; // Internal audit flag (will not leak)
    }

    /**
     * Publish representation: Hides internal audit flags and idempotency keys.
     */
    asJson() {
        return {
            id: this.id,
            studentId: this.studentId,
            scholarshipId: this.scholarshipId,
            status: this.status,
            reason: this.reason,
            createdAt: this.createdAt
        };
    }
}

module.exports = EvaluationRecord;