// eligibility/store.js
const evaluations = new Map();
const keysMap = new Map();
let nextId = 1;

module.exports = {
    findByKey(key) {
        if (keysMap.has(key)) {
            const id = keysMap.get(key);
            return evaluations.get(id) || null;
        }
        return null;
    },

    findById(id) {
        return evaluations.get(Number(id)) || null;
    },

    listAll(studentId, status) {
        let results = Array.from(evaluations.values());
        if (studentId !== undefined && studentId !== null) {
            results = results.filter(e => e.studentId === Number(studentId));
        }
        if (status) {
            results = results.filter(e => e.status === status);
        }
        return results;
    },

    save(record) {
        if (!record.id || record.id === 0) {
            record.id = nextId++;
        }
        evaluations.set(record.id, record);
        if (record.idempotencyKey) {
            keysMap.set(record.idempotencyKey, record.id);
        }
        return record;
    },

    clearStore() {
        evaluations.clear();
        keysMap.clear();
        nextId = 1;
    }
};