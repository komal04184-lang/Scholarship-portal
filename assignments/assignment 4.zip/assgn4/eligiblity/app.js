// eligibility/app.js
const express = require('express');
const EvaluationRecord = require('./models');
const store = require('./store');
const { problem } = require('./errors');
const { ScholarshipClient, ScholarshipServiceError } = require('./scholarshipclient');

const app = express();
app.use(express.json());

const scholarshipClient = new ScholarshipClient();

function validateEvaluationBody(data) {
    if (!data || typeof data !== 'object') return "Payload must be a JSON object";
    
    const required = ["studentId", "scholarshipId", "cgpa", "annualIncome"];
    for (const field of required) {
        if (data[field] === undefined || data[field] === null) {
            return `Missing required field: ${field}`;
        }
    }
    if (!Number.isInteger(data.studentId)) {
        return "Field 'studentId' must be an integer";
    }
    if (!Number.isInteger(data.scholarshipId)) {
        return "Field 'scholarshipId' must be an integer";
    }
    if (typeof data.cgpa !== 'number' || data.cgpa < 0.0 || data.cgpa > 10.0) {
        return "Field 'cgpa' must be a number between 0.0 and 10.0";
    }
    if (typeof data.annualIncome !== 'number' || data.annualIncome < 0) {
        return "Field 'annualIncome' must be a number >= 0";
    }
    return null;
}

// 1. POST /evaluations
app.post('/evaluations', async (req, res) => {
    const data = req.body;
    const validationError = validateEvaluationBody(data);
    if (validationError) {
        return problem(res, "invalid-request", "Invalid request body", 400, validationError);
    }

    // Check Idempotency Key
    const idemKey = req.headers['idempotency-key'];
    if (idemKey) {
        const existing = store.findByKey(idemKey);
        if (existing) {
            return res.status(200).json(existing.asJson());
        }
    }

    // Fetch Rules from Downstream Service
    let rules;
    try {
        rules = await scholarshipClient.getScholarshipRules(data.scholarshipId);
    } catch (err) {
        return problem(res, "service-unavailable", "Scholarship Service error", 503, err.message);
    }

    const minCgpa = rules.minCgpa ?? 8.0;
    const maxIncome = rules.maxIncome ?? 600000.0;

    // Evaluate Rules
    const isEligible = (data.cgpa >= minCgpa) && (data.annualIncome <= maxIncome);
    const status = isEligible ? 'ELIGIBLE' : 'INELIGIBLE';
    const reason = isEligible ? 'Criteria matched' : `Failed criteria (Min CGPA: ${minCgpa}, Max Income: ${maxIncome})`;

    const record = new EvaluationRecord({
        id: 0,
        studentId: data.studentId,
        scholarshipId: data.scholarshipId,
        cgpa: data.cgpa,
        annualIncome: data.annualIncome,
        status: status,
        reason: reason,
        idempotencyKey: idemKey,
        createdAt: new Date().toISOString()
    });

    const saved = store.save(record);
    res.setHeader('Location', `/evaluations/${saved.id}`);
    return res.status(201).json(saved.asJson());
});

// 2. GET /evaluations/:id
app.get('/evaluations/:id', (req, res) => {
    const record = store.findById(req.params.id);
    if (!record) {
        return problem(res, "not-found", "Evaluation not found", 404, `No evaluation found with ID ${req.params.id}`);
    }
    return res.status(200).json(record.asJson());
});

// 3. GET /evaluations
app.get('/evaluations', (req, res) => {
    const { studentId, status } = req.query;
    let parsedStudentId = null;

    if (studentId !== undefined) {
        parsedStudentId = parseInt(studentId, 10);
        if (isNaN(parsedStudentId)) {
            return problem(res, "invalid-query", "Invalid query parameter", 400, "studentId must be an integer");
        }
    }

    const records = store.listAll(parsedStudentId, status);
    return res.status(200).json(records.map(r => r.asJson()));
});

// 4. POST /evaluations/:id/override (State Conflict Sub-resource)
app.post('/evaluations/:id/override', (req, res) => {
    const record = store.findById(req.params.id);
    if (!record) {
        return problem(res, "not-found", "Evaluation not found", 404, `No evaluation found with ID ${req.params.id}`);
    }

    if (record.status === 'OVERRIDDEN') {
        return problem(res, "conflict", "State conflict", 409, `Evaluation ${req.params.id} is already in OVERRIDDEN state`);
    }

    const reason = req.body?.reason || "Administrative override";
    record.status = 'OVERRIDDEN';
    record.reason = `Overridden by Admin: ${reason}`;
    store.save(record);

    return res.status(202).json(record.asJson());
});

// Unknown route -> Problem body
app.use((req, res) => {
    return problem(res, "not-found", "Route not found", 404, `No route for ${req.method} ${req.path}`);
});

// Broken JSON (and any other unexpected error) -> Problem body, never an HTML page
app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') {
        return problem(res, "invalid-request", "Invalid request body", 400, "Body is not valid JSON");
    }
    return problem(res, "internal-error", "Internal server error", 500, "Unexpected error");
});

if (require.main === module) {
    const PORT = process.env.PORT || 8080;
    app.listen(PORT, () => console.log(`Eligibility Service running on port ${PORT}`));
}

module.exports = app;