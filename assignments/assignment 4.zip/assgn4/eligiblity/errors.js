// eligibility/errors.js  (RFC 7807-style Problem body)
function problem(res, code, title, status, detail) {
    return res.status(status).type('application/json').json({
        type: `/errors/${code}`,
        title: title,
        status: status,
        detail: detail
    });
}

module.exports = { problem };