// Tiny stand-in for the Scholarship Service (port 8081) - used only for the curl demo.
const http = require('http');

const rules = {
    1: { minCgpa: 8.0, maxIncome: 600000.0 },
    2: { minCgpa: 7.0, maxIncome: 400000.0 }
};

http.createServer((req, res) => {
    const m = req.url.match(/^\/scholarships\/(\d+)$/);
    const found = m && rules[m[1]];
    res.writeHead(found ? 200 : 404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(found || { error: 'not found' }));
}).listen(process.env.PORT || 8081, () => console.log('Mock Scholarship Service on 8081'));
