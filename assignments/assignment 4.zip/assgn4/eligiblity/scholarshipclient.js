// eligibility/scholarshipClient.js
const SCHOLARSHIP_URL = process.env.SCHOLARSHIP_URL || 'http://localhost:8081';

class ScholarshipServiceError extends Error {}

class ScholarshipClient {
    async getScholarshipRules(scholarshipId) {
        const url = `${SCHOLARSHIP_URL}/scholarships/${scholarshipId}`;

        // Exponential backoff with jitter (up to 3 attempts)
        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 2000);

                const response = await fetch(url, { signal: controller.signal });
                clearTimeout(timeoutId);

                if (response.ok) {
                    return await response.json();
                } else if (response.status === 400 || response.status === 404) {
                    throw new ScholarshipServiceError(`Scholarship ${scholarshipId} not found`);
                }
            } catch (err) {
                if (err instanceof ScholarshipServiceError) throw err;
                if (attempt === 3) {
                    // Fallback default rules if external service is unreachable
                    return { minCgpa: 8.0, maxIncome: 600000.0 };
                }
                const delay = Math.pow(2, attempt - 1) * 1000 + Math.random() * 200;
                await new Promise(res => setTimeout(res, delay));
            }
        }
        return { minCgpa: 8.0, maxIncome: 600000.0 };
    }
}

module.exports = { ScholarshipClient, ScholarshipServiceError };