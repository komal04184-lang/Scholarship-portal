// eligibility/tests/eligibility.test.js
// Downstream Scholarship Service is mocked: tests stay fast and offline.
jest.mock('../scholarshipclient', () => ({
    ScholarshipClient: jest.fn().mockImplementation(() => ({
        getScholarshipRules: jest.fn().mockResolvedValue({ minCgpa: 8.0, maxIncome: 600000.0 })
    })),
    ScholarshipServiceError: class ScholarshipServiceError extends Error {}
}));

const request = require('supertest');
const app = require('../app');
const store = require('../store');

beforeEach(() => {
    store.clearStore();
});

describe('Eligibility Service Unit Tests', () => {
    test('1. Create succeeds with 201 Created and Location header', async () => {
        const payload = { studentId: 101, scholarshipId: 1, cgpa: 8.8, annualIncome: 400000 };
        const res = await request(app)
            .post('/evaluations')
            .send(payload);

        expect(res.statusCode).toEqual(201);
        expect(res.headers).toHaveProperty('location');
        expect(res.body.status).toEqual('ELIGIBLE');
    });

    test('2. Idempotent repeat request returns original record with 200 OK', async () => {
        const payload = { studentId: 101, scholarshipId: 1, cgpa: 8.8, annualIncome: 400000 };
        const headers = { 'idempotency-key': 'KEY-12345' };

        const res1 = await request(app)
            .post('/evaluations')
            .set(headers)
            .send(payload);
        expect(res1.statusCode).toEqual(201);
        const firstId = res1.body.id;

        const res2 = await request(app)
            .post('/evaluations')
            .set(headers)
            .send(payload);
        expect(res2.statusCode).toEqual(200);
        expect(res2.body.id).toEqual(firstId);
    });

    test('3. Malformed request body returns 400 Bad Request with Problem Details', async () => {
        const payload = { studentId: 101, scholarshipId: 1, cgpa: 15.0, annualIncome: 400000 }; // Bad CGPA
        const res = await request(app)
            .post('/evaluations')
            .send(payload);

        expect(res.statusCode).toEqual(400);
        expect(res.body.type).toEqual('/errors/invalid-request');
    });

    test('4. Unknown ID returns 404 Not Found', async () => {
        const res = await request(app).get('/evaluations/9999');
        expect(res.statusCode).toEqual(404);
        expect(res.body.type).toEqual('/errors/not-found');
    });
});