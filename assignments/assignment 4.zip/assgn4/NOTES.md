# Assignment 4 - Eligibility Service (REST)

Stack: Node.js + Express. Contract: `eligiblity/openapi.yaml`. Tests: Jest + Supertest.

## 1. Resource table (from A4)

| Resource | URL | Method | Success | Errors | Notes |
|---|---|---|---|---|---|
| Evaluation collection | `/evaluations` | POST | 201 + `Location` | 400, 503 | Optional `Idempotency-Key`. Repeat with same key returns 200 and the original record. |
| Evaluation collection | `/evaluations?studentId=&status=` | GET | 200 | 400 | Filter by student and status. |
| Evaluation | `/evaluations/{id}` | GET | 200 | 404 | One evaluation. |
| Override (sub-resource) | `/evaluations/{id}/override` | POST | 202 | 404, 409 | Moves status to `OVERRIDDEN`. Second call gives 409. |

## 2. A5 justification

<!-- EDIT: match this to the exact wording of A5 in your brief. Draft below. -->
- Nouns, not verbs: the URLs name things (`/evaluations`), and the HTTP method says the action. The WSDL had operation names like `evaluateEligibility`; here POST on the collection does that job.
- Override is a sub-resource with POST, not a PUT/PATCH on status, because it is a business action with rules (it can only happen once) and it needs an audit reason. A repeat gives a clear 409 state conflict.
- 201 + `Location` on create tells the client where the new resource lives. 202 on override because it is accepted as an administrative decision.
- Idempotency-Key on POST makes retries safe: a network timeout and retry does not create two evaluations.
- Internal fields (`idempotencyKey`, `adminOverrideReason`, `cgpa`, `annualIncome`) are not returned. `asJson()` in `models.js` controls the public shape.

## 3. D3 fallback reasoning

<!-- EDIT: match this to the exact wording of D3 in your brief. Draft below. -->
`scholarshipclient.js` calls the Scholarship Service with a 2 second timeout and up to 3 attempts. Wait time grows as 1s, 2s (exponential) plus up to 200ms random jitter, so many clients do not retry at the same moment.

If the service is still unreachable after 3 attempts, the client falls back to default rules (`minCgpa 8.0`, `maxIncome 600000`) instead of failing. Reasoning: an evaluation is a read-style decision that an admin can later change with the override endpoint, so a slow downstream service should not block students. The risk is a decision based on stale default rules, which is why the override sub-resource exists.

If the service answers that the scholarship does not exist (404/400), there is no sensible default, so the client does not retry and the API returns an error Problem body instead.

## Answers

### 1. WSDL vs openapi.yaml line count

- Assignment 3 WSDL: **`<WSDL_LINES>` lines** (run `wc -l path/to/service.wsdl`)
- `openapi.yaml`: **196 lines**
- Difference: `<DIFFERENCE>` lines. <!-- EDIT: fill numbers -->

What the difference is made of: the WSDL had to describe everything about *how to talk*, because SOAP has no built-in meaning. It needed an XML Schema type block, a `<message>` for every request and response, a `<portType>` listing operations, a `<binding>` explaining SOAP over HTTP, and a `<service>`/`<port>` with the address. OpenAPI only describes *what* exists (paths, parameters, schemas, responses). HTTP already gives the how: verbs, status codes and URLs.

Two things the WSDL declared that OpenAPI does not need to:
1. **`<wsdl:message>` wrappers** (request and response message parts). In REST the body is just the JSON schema, and the response is a status code plus a body.
2. **`<wsdl:binding>` with `soap:binding` / `soapAction` / `style` / `use`.** HTTP is used as it is, so there is no envelope, no soapAction header and no encoding style to declare.

### 2. soap:Fault vs Problem body

soap:Fault from Assignment 3: <!-- EDIT: paste your real fault -->
```xml
<soap:Fault>
  <faultcode>soap:Client</faultcode>
  <faultstring>Evaluation not found</faultstring>
</soap:Fault>
```

Replacement in this service (`GET /evaluations/9999`):
```
HTTP/1.1 404 Not Found
Content-Type: application/json

{"type":"/errors/not-found","title":"Evaluation not found","status":404,"detail":"No evaluation found with ID 9999"}
```

Why a fault inside 200 OK is a problem: everything between client and server (proxies, caches, load balancers, API gateways, monitoring) reads only the status line. It cannot open the XML body. If a failure arrives as 200, a cache may store it as a good answer, retry logic never starts, health checks and dashboards show success, and alerts do not fire. With 404 or 409 the network can act correctly without understanding our message format.

### 3. UDDI: publish, find, bind

- **Publish - still exists, but changed form.** Publishing is now just making `openapi.yaml` available (repo, docs site, API portal). There is no registry server to register with.
- **Find - disappeared as a runtime step.** Nobody queries a registry at run time. A developer finds the API through documentation or a gateway catalogue and reads the contract.
- **Bind - disappeared as dynamic discovery.** The address is fixed in configuration: `servers:` in the OpenAPI file, and `SCHOLARSHIP_URL` in `scholarshipclient.js` for the downstream call. Because HTTP is the one uniform interface, no per-service binding description is needed.

What took over: the OpenAPI file (as the published contract) plus configuration and DNS (as the address), instead of a registry.

### 4. Who enforces the schema now

The function is **`validateEvaluationBody(data)`** in `eligiblity/app.js`. The XML Schema parser used to reject bad input before our code ran. In OpenAPI the schema is only documentation, so this function must check required fields and types by hand.

Failure that gets through without it: `{"studentId":101,"scholarshipId":1,"cgpa":15.0,"annualIncome":400000}`. Nothing else checks that CGPA is at most 10, so the service would save it as `ELIGIBLE`. Test 3 covers this case. Another one: `"cgpa":"9"` as a string would be compared by JavaScript type coercion and give a wrong result silently.

### 5. Where SOAP is still the better choice

<!-- EDIT: change if your Scholarship Portal has a different part you prefer. -->
**Scholarship disbursement instruction to the bank** (the money-transfer step after eligibility is confirmed).

Guarantee: **WS-ReliableMessaging** - each message is delivered exactly once and in order, or the sender receives a definite fault; together with **WS-Security** message-level signing, so the signature stays with the message across every intermediary and the bank can prove who sent the instruction (non-repudiation). REST with HTTPS only protects each hop, and delivery guarantees such as exactly-once have to be built by hand with idempotency keys and retries.
