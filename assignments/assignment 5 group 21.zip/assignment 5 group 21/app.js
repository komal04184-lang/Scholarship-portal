const express = require('express');
const crypto = require('crypto');
const zlib = require('zlib');

const app = express();
app.use(express.json());

const evaluations = new Map();
const idempotencyStore = new Map();
let nextId = 1;

function generateETag(data) {
    const jsonStr = JSON.stringify(data);
    const hash = crypto.createHash('md5').update(jsonStr).digest('hex').substring(0, 8);
    return `W/"${data.id || 0}-${hash}"`;
}

function problem(res, type, title, status, detail) {
    return res.status(status).type('application/json').json({
        type: `/errors/${type}`,
        title,
        status,
        detail
    });
}


// Task B7: Security Headers
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
});

// Task B5: Rate Limiting Middleware (Per Client IP)
const rateLimits = new Map();
app.use((req, res, next) => {
    const clientIp = req.ip || '127.0.0.1';
    const limit = 100;
    const current = rateLimits.get(clientIp) || { count: 0, reset: Date.now() + 60000 };

    if (Date.now() > current.reset) {
        current.count = 0;
        current.reset = Date.now() + 60000;
    }

    current.count++;
    rateLimits.set(clientIp, current);

    res.setHeader('X-RateLimit-Limit', limit);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, limit - current.count));

    if (current.count > limit) {
        res.setHeader('Retry-After', 60);
        return problem(res, 'rate-limit-exceeded', 'Too Many Requests', 429, 'Rate limit exceeded. Try again in 60 seconds.');
    }
    next();
});

// Task B6 & A5: CORS and Method Override Middleware
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Idempotency-Key, If-None-Match, If-Match, X-HTTP-Method-Override');

    if (req.headers['x-http-method-override']) {
        req.method = req.headers['x-http-method-override'].toUpperCase();
    }
    next();
});

// Task B1: Content Negotiation
app.use((req, res, next) => {
    const accept = req.headers['accept'];
    if (accept && !accept.includes('application/json') && !accept.includes('*/*')) {
        return problem(res, 'not-acceptable', 'Not Acceptable', 406, 'Client must accept application/json');
    }
    next();
});

// Task B3: Authorization Guard
const protectedAuth = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ') || authHeader.split(' ')[1].trim() === '') {
        return problem(res, 'unauthorized', 'Unauthorized', 401, 'Missing or empty Authorization Bearer token');
    }
    next();
};

// --- ENDPOINTS ---

// Task A5: OPTIONS Endpoint
app.options('/evaluations', (req, res) => {
    res.setHeader('Allow', 'GET, POST, OPTIONS');
    return res.status(204).send();
});

app.options('/evaluations/:id', (req, res) => {
    res.setHeader('Allow', 'GET, PUT, PATCH, DELETE, OPTIONS');
    return res.status(204).send();
});

// Task A1, B2, C3: POST /evaluations (Create with Idempotency & Gzip)
app.post('/evaluations', protectedAuth, (req, res) => {
    const idemKey = req.headers['idempotency-key'];
    if (idemKey && idempotencyStore.has(idemKey)) {
        const cached = idempotencyStore.get(idemKey);
        res.setHeader('Location', `/evaluations/${cached.id}`);
        res.setHeader('ETag', generateETag(cached));
        return res.status(200).json(cached);
    }

    const { studentId, scholarshipId, cgpa, annualIncome } = req.body || {};

    if (studentId === undefined || scholarshipId === undefined || cgpa === undefined || annualIncome === undefined) {
        return problem(res, 'invalid-request', 'Bad Request', 400, 'Missing required fields: studentId, scholarshipId, cgpa, annualIncome');
    }

    if (typeof cgpa !== 'number' || cgpa < 0.0 || cgpa > 10.0) {
        return problem(res, 'unprocessable-entity', 'Unprocessable Entity', 422, 'CGPA must be a valid number between 0.0 and 10.0');
    }

    const isEligible = cgpa >= 8.0 && annualIncome <= 600000;
    const record = {
        id: nextId++,
        studentId,
        scholarshipId,
        cgpa,
        annualIncome,
        status: isEligible ? 'ELIGIBLE' : 'INELIGIBLE',
        reason: isEligible ? 'Criteria matched' : 'Academic or income criteria not met',
        createdAt: new Date().toISOString()
    };

    evaluations.set(record.id, record);
    if (idemKey) {
        idempotencyStore.set(idemKey, record);
    }

    const etag = generateETag(record);
    res.setHeader('Location', `/evaluations/${record.id}`);
    res.setHeader('ETag', etag);
    res.setHeader('Cache-Control', 'no-store');

    return res.status(201).json(record);
});

// Task A4, B4, C1: GET /evaluations/:id (Conditional Read & ETag)
app.get('/evaluations/:id', protectedAuth, (req, res) => {
    const id = parseInt(req.params.id, 10);
    const record = evaluations.get(id);

    if (!record) {
        return problem(res, 'not-found', 'Not Found', 404, `Evaluation with ID ${id} not found`);
    }

    const etag = generateETag(record);
    const ifNoneMatch = req.headers['if-none-match'];

    if (ifNoneMatch === etag) {
        res.setHeader('ETag', etag);
        return res.status(304).send(); // Task C1: 304 Not Modified
    }

    res.setHeader('ETag', etag);
    res.setHeader('Cache-Control', 'private, max-age=60');
    return res.status(200).json(record);
});

// Task A4: GET /evaluations (Filtered Read)
app.get('/evaluations', protectedAuth, (req, res) => {
    let results = Array.from(evaluations.values());
    const { studentId, status } = req.query;

    if (studentId) {
        results = results.filter(e => e.studentId === parseInt(studentId, 10));
    }
    if (status) {
        results = results.filter(e => e.status === status);
    }

    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json(results);
});

// Task C2: PUT /evaluations/:id (Conditional Write with If-Match)
app.put('/evaluations/:id', protectedAuth, (req, res) => {
    const id = parseInt(req.params.id, 10);
    const record = evaluations.get(id);

    if (!record) {
        return problem(res, 'not-found', 'Not Found', 404, `Evaluation with ID ${id} not found`);
    }

    const currentETag = generateETag(record);
    const ifMatch = req.headers['if-match'];

    if (!ifMatch || ifMatch !== currentETag) {
        return problem(res, 'precondition-failed', 'Precondition Failed', 412, 'ETag in If-Match does not match current resource state');
    }

    const { cgpa, annualIncome } = req.body;
    if (cgpa !== undefined) record.cgpa = cgpa;
    if (annualIncome !== undefined) record.annualIncome = annualIncome;

    evaluations.set(id, record);
    const newETag = generateETag(record);
    res.setHeader('ETag', newETag);
    return res.status(200).json(record);
});

// Task A2: Non-CRUD State Overrides
app.post('/evaluations/:id/override', protectedAuth, (req, res) => {
    const id = parseInt(req.params.id, 10);
    const record = evaluations.get(id);

    if (!record) {
        return problem(res, 'not-found', 'Not Found', 404, `Evaluation with ID ${id} not found`);
    }

    if (record.status === 'OVERRIDDEN') {
        return problem(res, 'conflict', 'Conflict', 409, 'Evaluation has already been overridden');
    }

    record.status = 'OVERRIDDEN';
    record.reason = req.body.reason || 'Overridden by Admin';
    evaluations.set(id, record);

    return res.status(202).json(record);
});

// Task B2: DELETE Endpoint
app.delete('/evaluations/:id', protectedAuth, (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (!evaluations.has(id)) {
        return problem(res, 'not-found', 'Not Found', 404, `Evaluation with ID ${id} not found`);
    }
    evaluations.delete(id);
    return res.status(204).send();
});

const PORT = process.env.PORT || 8080;
if (require.main === module) {
    app.listen(PORT, () => console.log(`Scholarship Portal Service listening on port ${PORT}`));
}

module.exports = app;