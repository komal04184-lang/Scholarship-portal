# CS543 Assignment 5: HTTP Methods & Headers - Scholarship Portal

**Team ID:** Team-[Your_Team_ID]  
**Team Members:**  
20251651097 Tisha Bagra
20251651051 Komal
20251651045 Ishu Rajput
20251651103 Vinita Rathore
20251651080 Rupini C. Bhojannavar

---

## Part A: Method Map & Non-CRUD Modeling

### Task A1 & A3: Scholarship Portal Method Map & Property Audit

| Action Description | Method | URL Path | Safe? | Idempotent? | Status Code |
| :--- | :---: | :--- | :---: | :---: | :---: |
| List/Search Evaluations | GET | `/evaluations?studentId=101&status=ELIGIBLE` | Yes | Yes | 200 OK |
| Read Single Evaluation | GET | `/evaluations/12` | Yes | Yes | 200 OK |
| Create Evaluation | POST | `/evaluations` | No | No* | 201 Created |
| Update Evaluation Data | PUT | `/evaluations/12` | No | Yes | 200 OK |
| Partial Evaluation Patch | PATCH | `/evaluations/12` | No | No | 200 OK |
| Delete Evaluation Draft | DELETE | `/evaluations/12` | No | Yes | 204 No Content |
| Admin Decision Override | POST | `/evaluations/12/override` | No | No | 202 Accepted |
| Cancel Evaluation Request | POST | `/evaluations/12/cancel` | No | No | 200 OK |

*\* Note: `POST /evaluations` is made retry-safe using an `Idempotency-Key` header.*

### Task A2: Non-CRUD Modeling
Actions like `override` or `cancel` are not basic CRUD entity replacements. They are modeled as sub-resource POST endpoints (e.g., `POST /evaluations/12/override` and `POST /evaluations/12/cancel`) rather than embedding verbs into top-level URLs like `/overrideEvaluation`.

### Task A6: Full Request/Response Exchange
```http
--- REQUEST ---
POST /evaluations HTTP/1.1
Host: localhost:8080
Authorization: Bearer mock-valid-token-123
Content-Type: application/json
Accept: application/json
Idempotency-Key: SCHOLARSHIP-EVAL-2026-001
User-Agent: curl/8.7.1

{
  "studentId": 101,
  "scholarshipId": 1,
  "cgpa": 8.8,
  "annualIncome": 400000
}

--- RESPONSE ---
HTTP/1.1 201 Created
Location: /evaluations/1
ETag: W/"5a-a8f9b1c2"
Content-Type: application/json; charset=utf-8
Content-Encoding: gzip
Cache-Control: no-store
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 99
X-Content-Type-Options: nosniff
Strict-Transport-Security: max-age=31536000; includeSubDomains
Date: Tue, 13 Oct 2026 21:15:00 GMT
Connection: keep-alive

{
  "id": 1,
  "studentId": 101,
  "scholarshipId": 1,
  "status": "ELIGIBLE",
  "reason": "Criteria matched",
  "createdAt": "2026-10-13T21:15:00.000Z"
}


###Part D2: Headers Table
Endpoint                    ||||                Required Request Headers                       ||||Response Headers Set
POST /evaluations           ||||Authorization, Content-Type, Accept, Idempotency-Key (Optional)||||Location, ETag, Content-Type, X-RateLimit-*, X-Content-Type-Options, Strict-Transport-Security
GET /evaluations/{id}       ||||  Authorization, Accept, If-None-Match (Optional)               ||||ETag, Cache-Control, Content-Type, X-RateLimit-*, X-Content-Type-Options
PUT /evaluations/{id}       ||||    Authorization, Content-Type, Accept, If-Match               ||||ETag, Content-Type, X-RateLimit-*, X-Content-Type-Options
DELETE /evaluations/{id}    ||||            Authorization                                       ||||X-RateLimit-*, X-Content-Type-Options
OPTIONS /evaluations        ||||            Origin, Access-Control-Request-Method               ||||Allow, Access-Control-Allow-Origin, Access-Control-Allow-Methods, Access-Control-Allow-Headers

####Part C4: Safe-Retry Plan
Risky Endpoint          |||     Applied Mechanism       |||     Reason & Protection Provided
POST /evaluations       |||    Idempotency-Key          |||Prevents duplicate student evaluation records if a network timeout drops the response after the server completes evaluation.
GET /evaluations/{id}   ||| If-None-Match               |||Bandwidth optimization. Returns 304 Not Modified without a body if the       client's cached copy matches the server's ETag.
PUT /evaluations/{id}   |||If-Match                     |||Prevents lost updates (optimistic locking). Rejects updates with 412     Precondition Failed if another reviewer edited the evaluation in the meantime.Questions 


Question 1: Response Headers for Three Endpoints
POST /evaluations -> Success: 201 Created -> Header: Location: /evaluations/1.
Why: Informs the client of the authoritative URL where the newly created evaluation resource can be accessed.

GET /evaluations/1 -> Success: 200 OK-> Header: ETag: W/"5a-a8f9b1c2".
Why: Provides a version fingerprint of the evaluation state required for conditional re-reads (304) and conditional updates (412).

POST /evaluations/1/override -> Success: 202 Accepted -> Header: Content-Type: application/json.
Why: Declares that the payload format is JSON while confirming the asynchronous processing request was accepted.


Question 2: Safety & Idempotency Audit
Safe Endpoints: GET /evaluations and GET /evaluations/{id} (read-only, zero server state modification).
Idempotent Endpoints: GET /evaluations/{id}, PUT /evaluations/{id}, DELETE /evaluations/{id}.
Neither Safe nor Idempotent: POST /evaluations. Repeating this request could accidentally create multiple duplicate evaluation entries.Making POST Retry-Safe: We pass an Idempotency-Key header. The server stores the key alongside the evaluation output. Retried POST requests with the same key bypass processing and return the original response.


Question 3: ETag Cycle & Conditional Checks
Sample ETag: W/"5a-a8f9b1c2"
Conditional Read (If-None-Match): GET /evaluations/1 with If-None-Match: W/"5a-a8f9b1c2" returns 304 Not Modified with no response body. Saves bandwidth and network transmission.
Conditional Write (If-Match): PUT /evaluations/1 with an outdated If-Match: W/"old-tag" returns 412 Precondition Failed. Prevents lost updates when two reviewers edit the same evaluation simultaneously.


Question 4: 400 Bad Request vs. 422 Unprocessable Entity
400 Bad Request Example: Sending invalid JSON syntax or a string where a number is expected (e.g., "cgpa": "eight"). Indicates the client sent a malformed message structure that cannot be parsed.
422 Unprocessable Entity Example: Sending valid JSON with a CGPA value out of domain bounds (e.g., "cgpa": 12.0). Indicates the message format is structurally sound, but violates domain validation rules.


Question 5: CORS Blocking Mechanics
Who Blocked It: The Web Browser blocked the response from being exposed to the client-side JavaScript application, even though the server executed the request and returned 200 OK.
Fixing Header: The server must include Access-Control-Allow-Origin: * (or specify the origin URL) and handle OPTIONS preflight requests.


Question 6: Cache-Control Usage
Allowed Caching (Cache-Control: public, max-age=60): Used on public scholarship listings (GET /scholarships). Since public criteria do not change frequently and contain no private student data, caching improves efficiency.
Forbidden Caching (Cache-Control: no-store): Used on student-specific evaluations (GET /evaluations/1). Prevents shared proxy caches or web browsers from storing sensitive financial or demographic student data.


Question 7: GET vs. POST for Search Endpoints
When POST is Justified: When search query parameters are extremely complex, nested, or exceed URL length limits (2048 characters), or when the query payload contains sensitive filter data that should not appear in server access logs or browser history.
What is Sacrificed: Switching search from GET to POST forfeits standard HTTP caching, browser bookmarkability, and idempotency guarantees provided by native HTTP GET tools.


Question 8: Location Header Dual Meaning
On 201 Created: Points to the canonical URL of the newly created resource (e.g., /evaluations/1).
On 3xx Redirect (e.g., 301 or 302): Points to the target URL where the client must redirect its request.