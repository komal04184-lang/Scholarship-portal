**Team Members:**  
20251651097 Tisha Bagra
20251651051 Komal
20251651045 Ishu Rajput
20251651103 Vinita Rathore
20251651080 Rupini C. Bhojannavar

## 1. Status Map

| Endpoint | Action Description | Success Status | Failure Statuses & Triggers |
| :--- | :--- | :---: | :--- |
| `POST /applications` | Submit a scholarship application | `201 Created` | `400 Bad Request` (Malformed JSON structure)<br>`401 Unauthorized` (Missing Bearer Token)<br>`406 Not Acceptable` (Unsupported Accept Header)<br>`422 Unprocessable Content` (Validation failure: empty documents or invalid GPA/income)<br>`429 Too Many Requests` (Rate limit exceeded) |
| `GET /applications/{id}` | Read application details | `200 OK` | `401 Unauthorized`<br>`404 Not Found` (Unknown application ID)<br>`406 Not Acceptable` (Unsupported Accept Header) |
| `PATCH /applications/{id}` | Update application details / status | `200 OK` | `401 Unauthorized`<br>`404 Not Found` (Unknown application ID)<br>`409 Conflict` (Illegal state transition e.g., editing an already approved application)<br>`422 Unprocessable Content` (Validation failure) |
| `DELETE /applications/{id}` | Delete/withdraw a draft application | `204 No Content` | `401 Unauthorized`<br>`404 Not Found` (Unknown application ID)<br>`409 Conflict` (Cannot delete an application already under review/approved) |

---

## 2. Type Catalogue

| Stable Type String | HTTP Status | Triggering Condition |
| :--- | :---: | :--- |
| `empty-documents` | `422` | Student submitted an application with no supporting documents attached. |
| `invalid-field-value` | `422` | One or more input fields failed schema/range validation (e.g., CGPA < 0 or > 10). |
| `application-not-found` | `404` | No application record exists for the requested ID. |
| `illegal-transition` | `409` | Requested state change is invalid for the application's current lifecycle state (e.g., withdrawing an approved application). |
| `unauthorized` | `401` | Missing or malformed `Authorization: Bearer <token>` header. |
| `not-acceptable` | `406` | Client requested a format via `Accept` header that server cannot fulfill (only `application/json` and `application/xml` supported). |
| `rate-limit-exceeded` | `429` | Client exceeded maximum allowed request budget per window. |
| `internal-server-error` | `500` | Unhandled internal exception wrapped safely to prevent leaking sensitive system details. |

---

## 3. Labeled Problem Details Body Sample

```json
{
  "type": "[https://scholarship.portal/errors/invalid-field-value](https://scholarship.portal/errors/invalid-field-value)",  // Stable URI identifier for error classification
  "title": "Validation Failed",                                    // Short, human-readable summary
  "status": 422,                                                   // HTTP status code matching header
  "detail": "The request body contains 2 field validation errors.", // Detailed human-readable explanation
  "errors": [                                                      // Specific field-level error breakdowns
    {
      "field": "cgpa",
      "msg": "CGPA must be a number between 0.0 and 10.0"
    },
    {
      "field": "documents",
      "msg": "At least one supporting document must be provided"
    }
  ]
}

### 4. Field-Level 422 Response Reporting Multiple Bad Fields
HTTP
HTTP/1.1 422 Unprocessable Content
Content-Type: application/problem+json; charset=utf-8

{
  "type": "[https://scholarship.portal/errors/invalid-field-value](https://scholarship.portal/errors/invalid-field-value)",
  "title": "Validation Failed",
  "status": 422,
  "detail": "The request body contains 2 field validation errors.",
  "errors": [
    {
      "field": "cgpa",
      "msg": "CGPA must be a number between 0.0 and 10.0"
    },
    {
      "field": "annualIncome",
      "msg": "Annual income cannot be negative"
    }
  ]
}



#### 5. Retry Safety Analysis
## Safe to Retry:
429 Too Many Requests: Client should wait for the duration specified in the Retry-After header before retrying unchanged.
503 Service Unavailable: Transient server/downstream outage. Safe to retry with exponential backoff and jitter.
GET /applications/{id}: Safe and naturally idempotent read operation.

## NOT Safe to Retry Unchanged:
400 Bad Request, 401 Unauthorized, 404 Not Found, 409 Conflict, 422 Unprocessable Content: Domain/validation failures that will fail identically if retried without modifying request payload or server state.
POST /applications: Non-idempotent create operation. Safe to retry only if accompanied by an Idempotency-Key header.

#### 6. Internal Error Mapping & Abstraction
In app.js, database access and calculations are wrapped inside try/catch blocks:

JavaScript
try {
    // Risky DB operation or downstream RPC
    const result = database.query("SELECT * FROM applications WHERE id = " + appId);
} catch (err) {
    console.error("[INTERNAL DB ERROR]", err.stack); // Logged internally with full stack trace
    return problem(res, 500, "internal-server-error", "Internal Server Error", "An unexpected error occurred while processing your application.");
}
Hidden from Client: Database error messages, SQL syntax details, table names, system file paths, and stack traces.
Returned to Client: Clean RFC 7807 Problem Details object with status: 500.

#### 7. Content Negotiation (JSON vs XML)
##JSON Request & Response
Request:
HTTP
GET /applications/1 HTTP/1.1
Host: localhost:8080
Authorization: Bearer valid-token-123
Accept: application/json


Response:
HTTP
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8

{
  "id": 1,
  "studentId": 101,
  "scholarshipId": 1,
  "cgpa": 8.8,
  "annualIncome": 400000,
  "status": "SUBMITTED",
  "createdAt": "2026-10-13T10:00:00.000Z"
}

## XML Request & Response

Request:
HTTP
GET /applications/1 HTTP/1.1
Host: localhost:8080
Authorization: Bearer valid-token-123
Accept: application/xml

Response:
HTTP
HTTP/1.1 200 OK
Content-Type: application/xml; charset=utf-8

<?xml version="1.0" encoding="UTF-8"?>
<application>
  <id>1</id>
  <studentId>101</studentId>
  <scholarshipId>1</scholarshipId>
  <cgpa>8.8</cgpa>
  <annualIncome>400000</annualIncome>
  <status>SUBMITTED</status>
  <createdAt>2026-10-13T10:00:00.000Z</createdAt>
</application>