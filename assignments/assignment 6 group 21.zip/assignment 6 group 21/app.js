const express = require('express');
const app = express();

app.use(express.json());

const applications = new Map();
const idempotencyStore = new Map();
let nextId = 1;

function problem(res, status, typeCode, title, detail, errors = null) {
    res.setHeader('Content-Type', 'application/problem+json; charset=utf-8');
    const body = {
        type: `https://scholarship.portal/errors/${typeCode}`,
        title: title,
        status: status,
        detail: detail
    };
    if (errors && Array.isArray(errors) && errors.length > 0) {
        body.errors = errors;
    }
    return res.status(status).json(body);
}

function toXML(obj, rootName = 'application') {
    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<${rootName}>\n`;
    for (const [key, value] of Object.entries(obj)) {
        if (Array.isArray(value)) {
            xml += `  <${key}>\n`;
            value.forEach(item => {
                xml += `    <item>${typeof item === 'object' ? JSON.stringify(item) : item}</item>\n`;
            });
            xml += `  </${key}>\n`;
        } else {
            xml += `  <${key}>${value}</${key}>\n`;
        }
    }
    xml += `</${rootName}>`;
    return xml;
}

app.use((req, res, next) => {
    const accept = req.headers['accept'];
    if (accept && !accept.includes('application/json') && !accept.includes('application/xml') && !accept.includes('*/*')) {
        return problem(res, 406, 'not-acceptable', 'Not Acceptable', 'Server only supports application/json or application/xml responses.');
    }
    next();
});

const protectedAuth = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ') || authHeader.split(' ')[1].trim() === '') {
        return problem(res, 401, 'unauthorized', 'Unauthorized', 'Missing or empty Authorization Bearer token.');
    }
    next();
};

const rateLimits = new Map();
app.use((req, res, next) => {
    const clientIp = req.ip || '127.0.0.1';
    const limit = 50;
    const current = rateLimits.get(clientIp) || { count: 0, reset: Date.now() + 60000 };

    if (Date.now() > current.reset) {
        current.count = 0;
        current.reset = Date.now() + 60000;
    }

    current.count++;
    rateLimits.set(clientIp, current);

    res.setHeader('X-RateLimit-Limit', limit);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, limit - current.count));

    if (current.count > limit) {
        res.setHeader('Retry-After', '60');
        return problem(res, 429, 'rate-limit-exceeded', 'Too Many Requests', 'Rate limit exceeded. Please retry after 60 seconds.');
    }
    next();
});

function renderResponse(req, res, status, data, rootName = 'response') {
    const accept = req.headers['accept'] || '';
    if (accept.includes('application/xml')) {
        res.setHeader('Content-Type', 'application/xml; charset=utf-8');
        return res.status(status).send(toXML(data, rootName));
    }
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    return res.status(status).json(data);
}

function validateApplicationBody(body) {
    const validationErrors = [];

    if (!body || typeof body !== 'object') {
        validationErrors.push({ field: 'body', msg: 'Request body must be a valid JSON object' });
        return validationErrors;
    }

    if (!body.studentId || typeof body.studentId !== 'number') {
        validationErrors.push({ field: 'studentId', msg: 'studentId is required and must be a number' });
    }

    if (!body.scholarshipId || typeof body.scholarshipId !== 'number') {
        validationErrors.push({ field: 'scholarshipId', msg: 'scholarshipId is required and must be a number' });
    }

    if (body.cgpa === undefined || typeof body.cgpa !== 'number' || body.cgpa < 0.0 || body.cgpa > 10.0) {
        validationErrors.push({ field: 'cgpa', msg: 'CGPA must be a number between 0.0 and 10.0' });
    }

    if (body.annualIncome === undefined || typeof body.annualIncome !== 'number' || body.annualIncome < 0) {
        validationErrors.push({ field: 'annualIncome', msg: 'Annual income cannot be negative' });
    }

    if (!body.documents || !Array.isArray(body.documents) || body.documents.length === 0) {
        validationErrors.push({ field: 'documents', msg: 'At least one supporting document must be provided' });
    }

    return validationErrors;
}

// --- ENDPOINTS ---

// 1. POST /applications (Submit Application)
app.post('/applications', protectedAuth, (req, res) => {
    try {
        const idemKey = req.headers['idempotency-key'];
        if (idemKey && idempotencyStore.has(idemKey)) {
            const cached = idempotencyStore.get(idemKey);
            res.setHeader('Location', `/applications/${cached.id}`);
            return renderResponse(req, res, 200, cached, 'application');
        }

        const validationErrors = validateApplicationBody(req.body);
        if (validationErrors.length > 0) {
            return problem(res, 422, 'invalid-field-value', 'Validation Failed', `The request body contains ${validationErrors.length} field validation errors.`, validationErrors);
        }

        const record = {
            id: nextId++,
            studentId: req.body.studentId,
            scholarshipId: req.body.scholarshipId,
            cgpa: req.body.cgpa,
            annualIncome: req.body.annualIncome,
            documents: req.body.documents,
            status: 'SUBMITTED',
            createdAt: new Date().toISOString()
        };

        applications.set(record.id, record);
        if (idemKey) {
            idempotencyStore.set(idemKey, record);
        }

        res.setHeader('Location', `/applications/${record.id}`);
        return renderResponse(req, res, 201, record, 'application');
    } catch (err) {
        console.error("[INTERNAL ERROR]", err);
        return problem(res, 500, 'internal-server-error', 'Internal Server Error', 'An unexpected error occurred while processing application submission.');
    }
});

// 2. GET /applications/:id (Read Application)
app.get('/applications/:id', protectedAuth, (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const record = applications.get(id);

        if (!record) {
            return problem(res, 404, 'application-not-found', 'Application Not Found', `No scholarship application found for ID ${req.params.id}.`);
        }

        return renderResponse(req, res, 200, record, 'application');
    } catch (err) {
        console.error("[INTERNAL ERROR]", err);
        return problem(res, 500, 'internal-server-error', 'Internal Server Error', 'An unexpected error occurred while fetching the application.');
    }
});

// 3. PATCH /applications/:id (Update Status / Data)
app.patch('/applications/:id', protectedAuth, (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const record = applications.get(id);

        if (!record) {
            return problem(res, 404, 'application-not-found', 'Application Not Found', `No scholarship application found for ID ${req.params.id}.`);
        }

        if (record.status === 'APPROVED' || record.status === 'DISBURSED') {
            return problem(res, 409, 'illegal-transition', 'Illegal State Transition', `Cannot modify application in status ${record.status}.`);
        }

        if (req.body.cgpa !== undefined) {
            if (typeof req.body.cgpa !== 'number' || req.body.cgpa < 0.0 || req.body.cgpa > 10.0) {
                return problem(res, 422, 'invalid-field-value', 'Validation Failed', 'CGPA must be a number between 0.0 and 10.0', [{ field: 'cgpa', msg: 'Invalid CGPA range' }]);
            }
            record.cgpa = req.body.cgpa;
        }

        if (req.body.status) {
            record.status = req.body.status;
        }

        applications.set(id, record);
        return renderResponse(req, res, 200, record, 'application');
    } catch (err) {
        console.error("[INTERNAL ERROR]", err);
        return problem(res, 500, 'internal-server-error', 'Internal Server Error', 'An unexpected error occurred during application update.');
    }
});

// 4. DELETE /applications/:id (Withdraw/Delete Application)
app.delete('/applications/:id', protectedAuth, (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const record = applications.get(id);

        if (!record) {
            return problem(res, 404, 'application-not-found', 'Application Not Found', `No scholarship application found for ID ${req.params.id}.`);
        }

        if (record.status === 'APPROVED' || record.status === 'DISBURSED') {
            return problem(res, 409, 'illegal-transition', 'Illegal State Transition', `Cannot delete an application that has already reached state ${record.status}.`);
        }

        applications.delete(id);
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        return res.status(204).send();
    } catch (err) {
        console.error("[INTERNAL ERROR]", err);
        return problem(res, 500, 'internal-server-error', 'Internal Server Error', 'An unexpected error occurred during deletion.');
    }
});

const PORT = process.env.PORT || 8080;
if (require.main === module) {
    app.listen(PORT, () => console.log(`Scholarship Application Service listening on port ${PORT}`));
}

module.exports = app;